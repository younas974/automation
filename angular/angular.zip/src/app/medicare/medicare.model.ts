

export class userModel{
firstName:string ="";
lastName:string ="";
email : string="";
phoneNumber:number=0;
street:number=0;
city:string ="";
state:string ="";
zipCode:number =0;
}

